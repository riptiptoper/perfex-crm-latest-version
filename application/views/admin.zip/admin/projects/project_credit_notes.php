<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>
<div class="panel_s panel-table-full">
    <div class="panel-body">
        <?php $this->load->view('admin/credit_notes/table_html'); ?>
    </div>
</div>